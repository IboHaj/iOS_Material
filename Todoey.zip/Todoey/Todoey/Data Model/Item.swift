//
//  Item.swift
//  Todoey
//
//  Created by Ibrahim on 2/13/18.
//  Copyright © 2018 Ibrahim. All rights reserved.
//

import Foundation


class Item: Codable{
    var title : String = ""
    var done : Bool = false
    
}
